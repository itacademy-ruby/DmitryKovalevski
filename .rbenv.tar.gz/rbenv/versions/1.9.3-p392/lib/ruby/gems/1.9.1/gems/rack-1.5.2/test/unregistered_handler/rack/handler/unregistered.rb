module Rack
  module Handler
    # this class doesn't do anything, we're just seeing if we get it.
    class Unregistered
    end
  end
end